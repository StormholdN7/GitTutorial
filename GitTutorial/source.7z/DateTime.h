#pragma once
#include <string>       // std::string
#include <iostream>
#include <ctime>

using namespace std;

class CustomDateTime {
private:
	std::time_t timeMark;

	tm RebuildDays(tm Time);

public:
	/**
	* Allows to set custom date from provided variables
	* 
	* 
	* @Param - Enter Numeric values in format YYYY-MM-DD hh:mm:ss; Date is mandatory, Time is optional and defaults to 00:00:00
	*/
	void setDate(int Year, int Month, int Day, int Hour = 0, int Minutes = 0, int Seconds = 0);

	/**
	*Returns date in String Format
	*
	*
	*/
	string getDate() const;

	//===============================

	CustomDateTime();
	~CustomDateTime();


	//===============================
	/**
	*Returns date in String Format
	*
	*
	*/
	string toString();
};